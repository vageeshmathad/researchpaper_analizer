import { Router, type IRouter } from "express";
import { getDb } from "../lib/mongo";
import { seedFromCsv } from "../lib/seed";
import {
  ListPapersQueryParams,
  GetPaperParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/papers", async (req, res): Promise<void> => {
  const parsed = ListPapersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const db = await getDb();
    const query: Record<string, unknown> = {};

    if (parsed.data.domain) {
      query.domain = parsed.data.domain;
    }
    if (parsed.data.year) {
      query.year = Number(parsed.data.year);
    }
    if (parsed.data.search) {
      query.$or = [
        { title: { $regex: parsed.data.search, $options: "i" } },
        { abstract: { $regex: parsed.data.search, $options: "i" } },
        { authors: { $regex: parsed.data.search, $options: "i" } },
      ];
    }

    const papers = await db.collection("papers").find(query).sort({ ingestedAt: -1 }).toArray();

    const relationsCollection = db.collection("relations");
    const paperIds = papers.map((p) => p.paperId as string);

    const relationCounts = await relationsCollection
      .aggregate([
        { $match: { $or: [{ paperIdA: { $in: paperIds } }, { paperIdB: { $in: paperIds } }] } },
        {
          $group: {
            _id: null,
            counts: { $push: { a: "$paperIdA", b: "$paperIdB" } },
          },
        },
      ])
      .toArray();

    const countMap = new Map<string, number>();
    if (relationCounts.length > 0) {
      const allRelations = await relationsCollection.find({}).toArray();
      for (const rel of allRelations) {
        countMap.set(rel.paperIdA as string, (countMap.get(rel.paperIdA as string) ?? 0) + 1);
        countMap.set(rel.paperIdB as string, (countMap.get(rel.paperIdB as string) ?? 0) + 1);
      }
    }

    const result = papers.map((p) => ({
      id: p._id.toString(),
      paperId: p.paperId,
      title: p.title,
      authors: p.authors,
      year: p.year,
      domain: p.domain,
      keywords: p.keywords ?? [],
      abstract: p.abstract ?? "",
      summary: p.summary ?? "",
      keyPoints: p.keyPoints ?? [],
      relationCount: countMap.get(p.paperId as string) ?? 0,
      ingestedAt: p.ingestedAt,
    }));

    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to list papers");
    res.status(500).json({ error: String(err) });
  }
});

router.post("/papers", async (req, res): Promise<void> => {
  try {
    const db = await getDb();
    const { papersInserted, relationsInserted } = await seedFromCsv(db);

    const papers = await db.collection("papers").find({}).toArray();
    const paperIds = papers.map((p) => p.paperId as string);

    res.json({ paperIds, status: "indexed", count: papersInserted, relationsInserted });
  } catch (err) {
    req.log.error({ err }, "Failed to ingest papers");
    res.status(500).json({ error: String(err) });
  }
});

router.get("/papers/:paperId", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.paperId) ? req.params.paperId[0] : req.params.paperId;
  const params = GetPaperParams.safeParse({ paperId: rawId });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  try {
    const db = await getDb();
    const paper = await db.collection("papers").findOne({ paperId: params.data.paperId });

    if (!paper) {
      res.status(404).json({ error: "Paper not found" });
      return;
    }

    const relations = await db.collection("relations").find({
      $or: [{ paperIdA: params.data.paperId }, { paperIdB: params.data.paperId }],
    }).toArray();

    const formattedRelations = relations.map((r) => ({
      id: r._id.toString(),
      paperIdA: r.paperIdA,
      paperIdB: r.paperIdB,
      relation: r.relation,
      confidence: r.confidence,
      evidenceText: r.evidenceText ?? "",
      detectedAt: r.detectedAt,
    }));

    res.json({
      id: paper._id.toString(),
      paperId: paper.paperId,
      title: paper.title,
      authors: paper.authors,
      year: paper.year,
      domain: paper.domain,
      keywords: paper.keywords ?? [],
      abstract: paper.abstract ?? "",
      summary: paper.summary ?? "",
      keyPoints: paper.keyPoints ?? [],
      relationCount: formattedRelations.length,
      ingestedAt: paper.ingestedAt,
      relations: formattedRelations,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get paper");
    res.status(500).json({ error: String(err) });
  }
});

export default router;
