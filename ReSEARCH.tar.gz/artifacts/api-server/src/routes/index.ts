import { Router, type IRouter } from "express";
import healthRouter from "./health";
import papersRouter from "./papers";
import relationsRouter from "./relations";
import reviewRouter from "./review";
import qaRouter from "./qa";
import graphRouter from "./graph";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(papersRouter);
router.use(relationsRouter);
router.use(reviewRouter);
router.use(qaRouter);
router.use(graphRouter);
router.use(statsRouter);

export default router;
