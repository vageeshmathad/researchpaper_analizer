import { Router, type IRouter } from "express";
import { getDb } from "../lib/mongo";
import { GetGraphQueryParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/graph", async (req, res): Promise<void> => {
  const parsed = GetGraphQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const db = await getDb();
    const minConf = parsed.data.minConfidence ? Number(parsed.data.minConfidence) : 0;
    const relationType = parsed.data.relationType;

    const relQuery: Record<string, unknown> = {};
    if (minConf > 0) relQuery.confidence = { $gte: minConf };
    if (relationType) relQuery.relation = relationType;

    const relations = await db.collection("relations").find(relQuery).toArray();

    // Only include papers that have relations
    const paperIds = new Set<string>();
    for (const r of relations) {
      paperIds.add(r.paperIdA as string);
      paperIds.add(r.paperIdB as string);
    }

    const papers = await db.collection("papers").find(
      paperIds.size > 0 ? { paperId: { $in: Array.from(paperIds) } } : {}
    ).toArray();

    // Count relations per paper for node size
    const countMap = new Map<string, number>();
    for (const r of relations) {
      countMap.set(r.paperIdA as string, (countMap.get(r.paperIdA as string) ?? 0) + 1);
      countMap.set(r.paperIdB as string, (countMap.get(r.paperIdB as string) ?? 0) + 1);
    }

    const nodes = papers.map((p) => ({
      id: p.paperId as string,
      title: p.title as string,
      domain: p.domain as string,
      year: p.year as number,
      size: countMap.get(p.paperId as string) ?? 1,
    }));

    const edges = relations.map((r) => ({
      source: r.paperIdA as string,
      target: r.paperIdB as string,
      relation: r.relation as string,
      confidence: r.confidence as number,
    }));

    res.json({ nodes, edges });
  } catch (err) {
    req.log.error({ err }, "Failed to get graph");
    res.status(500).json({ error: String(err) });
  }
});

export default router;
