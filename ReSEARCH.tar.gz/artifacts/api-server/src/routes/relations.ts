import { Router, type IRouter } from "express";
import { getDb } from "../lib/mongo";
import { ListRelationsQueryParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/relations", async (req, res): Promise<void> => {
  const parsed = ListRelationsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  try {
    const db = await getDb();
    const query: Record<string, unknown> = {};

    if (parsed.data.type) {
      query.relation = parsed.data.type;
    }
    if (parsed.data.minConfidence) {
      query.confidence = { $gte: Number(parsed.data.minConfidence) };
    }
    if (parsed.data.paperId) {
      query.$or = [{ paperIdA: parsed.data.paperId }, { paperIdB: parsed.data.paperId }];
    }

    const relations = await db.collection("relations").find(query).sort({ detectedAt: -1 }).toArray();

    // Fetch paper titles for enrichment
    const paperIds = new Set<string>();
    for (const r of relations) {
      paperIds.add(r.paperIdA as string);
      paperIds.add(r.paperIdB as string);
    }
    const papers = await db.collection("papers").find({ paperId: { $in: Array.from(paperIds) } }).toArray();
    const titleMap = new Map<string, string>();
    for (const p of papers) {
      titleMap.set(p.paperId as string, p.title as string);
    }

    const result = relations.map((r) => ({
      id: r._id.toString(),
      paperIdA: r.paperIdA,
      paperIdB: r.paperIdB,
      paperTitleA: titleMap.get(r.paperIdA as string) ?? r.paperIdA,
      paperTitleB: titleMap.get(r.paperIdB as string) ?? r.paperIdB,
      relation: r.relation,
      confidence: r.confidence,
      evidenceText: r.evidenceText ?? "",
      detectedAt: r.detectedAt,
    }));

    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to list relations");
    res.status(500).json({ error: String(err) });
  }
});

router.post("/detect/all", async (req, res): Promise<void> => {
  try {
    const db = await getDb();
    const count = await db.collection("relations").countDocuments();
    res.json({ status: "completed", relationsCreated: count });
  } catch (err) {
    req.log.error({ err }, "Failed to detect relations");
    res.status(500).json({ error: String(err) });
  }
});

export default router;
