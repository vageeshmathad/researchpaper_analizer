import { readFileSync } from "fs";
import { resolve } from "path";
import type { Db } from "mongodb";
import { logger } from "./logger";

interface CsvRow {
  paper_id: string;
  title: string;
  abstract: string;
  summary: string;
  key_points: string;
  authors: string;
  year: string;
  domain: string;
  keywords: string;
  related_paper_id: string;
  relation_type: string;
  confidence_score: string;
  evidence_text: string;
  question: string;
  answer: string;
}

function parseCsv(content: string): CsvRow[] {
  const lines = content.trim().split("\n");
  const headers = lines[0].split(",");
  const rows: CsvRow[] = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    // Handle quoted fields
    const values: string[] = [];
    let current = "";
    let inQuotes = false;
    for (let j = 0; j < line.length; j++) {
      const ch = line[j];
      if (ch === '"') {
        inQuotes = !inQuotes;
      } else if (ch === "," && !inQuotes) {
        values.push(current.trim());
        current = "";
      } else {
        current += ch;
      }
    }
    values.push(current.trim());

    const row: Record<string, string> = {};
    headers.forEach((h, idx) => {
      row[h.trim()] = values[idx] ?? "";
    });
    rows.push(row as unknown as CsvRow);
  }
  return rows;
}

const DOMAINS = ["NLP", "Computer Vision", "Reinforcement Learning", "AI", "ML", "Robotics"];

function domainFromKeywords(keywords: string, domain: string): string {
  const kw = (keywords + " " + domain).toLowerCase();
  if (kw.includes("nlp") || kw.includes("language") || kw.includes("transformer")) return "NLP";
  if (kw.includes("vision") || kw.includes("cv") || kw.includes("image")) return "Computer Vision";
  if (kw.includes("rl") || kw.includes("reinforcement")) return "Reinforcement Learning";
  if (kw.includes("robot")) return "Robotics";
  return DOMAINS[Math.floor(Math.random() * DOMAINS.length)];
}

export async function seedFromCsv(db: Db): Promise<{ papersInserted: number; relationsInserted: number }> {
  const csvPath = resolve(process.cwd(), "../../attached_assets/high_accuracy_merged_dataset_1778016544507.csv");

  let content: string;
  try {
    content = readFileSync(csvPath, "utf-8");
  } catch (err) {
    logger.error({ err }, "Could not read CSV file");
    throw new Error("CSV file not found");
  }

  const rows = parseCsv(content);

  // Deduplicate papers by paper_id
  const paperMap = new Map<string, object>();
  for (const row of rows) {
    if (!row.paper_id || paperMap.has(row.paper_id)) continue;
    const domain = domainFromKeywords(row.keywords, row.domain);
    paperMap.set(row.paper_id, {
      paperId: row.paper_id,
      title: row.title || `Research Paper ${row.paper_id}`,
      abstract: row.abstract || "",
      summary: row.summary || "",
      keyPoints: row.key_points ? row.key_points.split(";").map((s) => s.trim()).filter(Boolean) : [],
      authors: row.authors || "Unknown Authors",
      year: parseInt(row.year, 10) || 2020,
      domain,
      keywords: row.keywords ? row.keywords.split(";").map((s) => s.trim()).filter(Boolean) : [],
      ingestedAt: new Date(),
    });
  }

  const papers = Array.from(paperMap.values());
  const papersCollection = db.collection("papers");
  const relationsCollection = db.collection("relations");

  // Clear and re-insert
  await papersCollection.deleteMany({});
  if (papers.length > 0) {
    await papersCollection.insertMany(papers);
  }

  // Build relations from CSV
  const relations: object[] = [];
  const seen = new Set<string>();
  for (const row of rows) {
    if (!row.paper_id || !row.related_paper_id || row.paper_id === row.related_paper_id) continue;
    const key = [row.paper_id, row.related_paper_id].sort().join("||");
    if (seen.has(key)) continue;
    seen.add(key);

    const relationType = (row.relation_type || "neutral").toLowerCase();
    const normalized = relationType === "support" ? "support" :
      relationType === "contradict" ? "contradict" :
      relationType === "agree" ? "agree" : "neutral";

    relations.push({
      paperIdA: row.paper_id,
      paperIdB: row.related_paper_id,
      relation: normalized,
      confidence: parseFloat(row.confidence_score) || 0.85,
      evidenceText: row.evidence_text || "",
      detectedAt: new Date(),
    });
  }

  await relationsCollection.deleteMany({});
  if (relations.length > 0) {
    await relationsCollection.insertMany(relations);
  }

  logger.info({ papersInserted: papers.length, relationsInserted: relations.length }, "Seeded from CSV");
  return { papersInserted: papers.length, relationsInserted: relations.length };
}
