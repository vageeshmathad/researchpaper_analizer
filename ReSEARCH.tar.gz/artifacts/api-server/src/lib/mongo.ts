import { MongoClient, type Db } from "mongodb";
import { logger } from "./logger";

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  logger.warn(
    "MONGODB_URI is not set — MongoDB features will be unavailable. Set MONGODB_URI in your environment secrets.",
  );
}

let client: MongoClient | null = null;
let db: Db | null = null;

export async function getDb(): Promise<Db> {
  if (!MONGODB_URI) {
    throw new Error(
      "MONGODB_URI environment variable is not set. Please add it in the Secrets tab.",
    );
  }
  if (!client) {
    client = new MongoClient(MONGODB_URI);
    await client.connect();
    db = client.db("research");
    logger.info("Connected to MongoDB");
  }
  return db!;
}

export async function closeMongo(): Promise<void> {
  if (client) {
    await client.close();
    client = null;
    db = null;
  }
}
