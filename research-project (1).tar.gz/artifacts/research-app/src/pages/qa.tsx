import React, { useState } from "react";
import { Shell } from "@/components/layout/Shell";
import { useListPapers, useAskQuestion } from "@workspace/api-client-react";
import { Send, Search, Terminal, Loader2, FileText, CheckSquare, Square } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

export default function QA() {
  const { data: papers, isLoading: papersLoading } = useListPapers();
  const [selectedPapers, setSelectedPapers] = useState<Set<string>>(new Set());
  const [question, setQuestion] = useState("");
  const ask = useAskQuestion();
  const { toast } = useToast();
  
  const [history, setHistory] = useState<Array<{
    role: "user" | "ai",
    content: string,
    sources?: any[],
    confidence?: number
  }>>([
    {
      role: "ai",
      content: "AI-12 KNOWLEDGE RETRIEVAL SYSTEM ONLINE.\nSelect papers from the corpus and enter your query. I will synthesize an answer mapped directly to source evidence."
    }
  ]);

  const togglePaper = (id: string) => {
    const newSet = new Set(selectedPapers);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedPapers(newSet);
  };

  const toggleAll = () => {
    if (!papers) return;
    if (selectedPapers.size === papers.length) {
      setSelectedPapers(new Set());
    } else {
      setSelectedPapers(new Set(papers.map(p => p.id)));
    }
  };

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    if (selectedPapers.size === 0) {
      toast({ variant: "destructive", title: "ERROR", description: "Select at least one paper as source." });
      return;
    }

    const q = question;
    setQuestion("");
    setHistory(prev => [...prev, { role: "user", content: q }]);

    try {
      const res = await ask.mutateAsync({
        data: {
          question: q,
          paperIds: Array.from(selectedPapers)
        }
      });
      
      setHistory(prev => [...prev, { 
        role: "ai", 
        content: res.answer,
        sources: res.sources,
        confidence: res.confidence
      }]);
    } catch (err) {
      setHistory(prev => [...prev, { 
        role: "ai", 
        content: "ERR_PROCESSING_QUERY: Neural pathway disconnected. Please try again."
      }]);
    }
  };

  const exampleChips = [
    "What are the main contradictions regarding this topic?",
    "Summarize the consensus across these papers.",
    "Identify methodology flaws mentioned in recent work."
  ];

  return (
    <Shell>
      <div className="container mx-auto px-6 py-6 h-[calc(100vh-3.5rem)] flex flex-col md:flex-row gap-6 max-w-[1600px]">
        {/* Left: Paper Selection */}
        <div className="w-full md:w-1/3 lg:w-1/4 flex flex-col glass-panel rounded-sm border border-card-border overflow-hidden">
          <div className="p-4 border-b border-card-border bg-card/80">
            <h2 className="font-display font-bold tracking-widest text-sm text-white mb-4">CORPUS SELECTION</h2>
            <div className="flex justify-between items-center">
              <span className="font-sans text-xs text-primary">{selectedPapers.size} SELECTED</span>
              <button 
                onClick={toggleAll}
                className="font-sans text-[10px] tracking-widest uppercase text-muted-foreground hover:text-white transition-colors"
              >
                {selectedPapers.size === papers?.length ? "CLEAR ALL" : "SELECT ALL"}
              </button>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2 custom-scrollbar">
            {papersLoading ? (
              <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
            ) : (
              papers?.map(paper => (
                <div 
                  key={paper.id}
                  onClick={() => togglePaper(paper.id)}
                  className={`flex items-start gap-3 p-3 rounded-sm cursor-pointer transition-colors mb-1 ${
                    selectedPapers.has(paper.id) ? "bg-primary/10 border border-primary/30" : "hover:bg-white/5 border border-transparent"
                  }`}
                >
                  <div className="mt-0.5 text-primary">
                    {selectedPapers.has(paper.id) ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4 text-muted-foreground" />}
                  </div>
                  <div>
                    <div className="font-sans text-xs text-white leading-tight line-clamp-2">{paper.title}</div>
                    <div className="font-sans text-[10px] text-muted-foreground mt-1 tracking-widest uppercase">{paper.domain} • {paper.year}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right: Chat Interface */}
        <div className="w-full md:w-2/3 lg:w-3/4 flex flex-col glass-panel rounded-sm border border-card-border overflow-hidden relative">
          <div className="absolute inset-0 pointer-events-none opacity-5">
            <div className="w-full h-full bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]" />
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar z-10">
            {history.map((msg, i) => (
              <div key={i} className={`flex gap-4 ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                {msg.role === "ai" && (
                  <div className="w-8 h-8 shrink-0 rounded bg-primary/20 border border-primary/50 flex items-center justify-center text-primary mt-1">
                    <Terminal className="w-4 h-4" />
                  </div>
                )}
                
                <div className={`max-w-[85%] ${
                  msg.role === "user" 
                    ? "bg-primary text-primary-foreground p-4 rounded-tl-xl rounded-bl-xl rounded-br-xl" 
                    : "bg-black/40 border border-primary/20 p-5 rounded-tr-xl rounded-bl-xl rounded-br-xl font-sans"
                }`}>
                  <div className="whitespace-pre-wrap text-sm leading-relaxed">
                    {msg.content}
                  </div>
                  
                  {msg.sources && msg.sources.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-primary/20 space-y-3">
                      <div className="text-[10px] text-primary tracking-widest uppercase font-bold">SOURCE CITATIONS</div>
                      {msg.sources.map((src, idx) => (
                        <div key={idx} className="bg-black/30 p-3 border border-white/5 rounded-sm">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded shadow-[0_0_10px_rgba(0,245,255,0.2)]">
                              [P{idx+1}]
                            </span>
                            <Link href={`/paper/${src.paperId}`} className="text-xs text-white hover:text-primary transition-colors line-clamp-1">
                              {src.paperTitle || src.paperId}
                            </Link>
                          </div>
                          <p className="text-[11px] text-muted-foreground italic border-l-2 border-primary/30 pl-2 ml-1">
                            "{src.excerpt}"
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                  {msg.confidence && (
                     <div className="mt-2 text-right">
                       <span className="text-[9px] text-primary/70 tracking-widest uppercase border border-primary/20 px-1.5 py-0.5 rounded">
                         CONFIDENCE: {(msg.confidence * 100).toFixed(1)}%
                       </span>
                     </div>
                  )}
                </div>

                {msg.role === "user" && (
                  <div className="w-8 h-8 shrink-0 rounded bg-white/10 border border-white/20 flex items-center justify-center text-white mt-1">
                    <Search className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}
            {ask.isPending && (
              <div className="flex gap-4 justify-start">
                <div className="w-8 h-8 shrink-0 rounded bg-primary/20 border border-primary/50 flex items-center justify-center text-primary mt-1">
                  <Terminal className="w-4 h-4" />
                </div>
                <div className="bg-black/40 border border-primary/20 p-4 rounded-tr-xl rounded-bl-xl rounded-br-xl font-sans flex items-center gap-3">
                  <Loader2 className="w-4 h-4 text-primary animate-spin" />
                  <span className="text-xs text-primary tracking-widest uppercase animate-pulse">Synthesizing response...</span>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 border-t border-card-border bg-card/80 z-10 shrink-0">
            <div className="flex flex-wrap gap-2 mb-3">
              {exampleChips.map((chip, i) => (
                <button
                  key={i}
                  onClick={() => setQuestion(chip)}
                  className="font-sans text-[10px] text-muted-foreground border border-white/10 px-2 py-1 rounded-full hover:bg-primary/10 hover:text-primary hover:border-primary/30 transition-colors"
                >
                  {chip}
                </button>
              ))}
            </div>
            <form onSubmit={handleAsk} className="flex gap-2">
              <input
                type="text"
                value={question}
                onChange={e => setQuestion(e.target.value)}
                placeholder={selectedPapers.size > 0 ? "QUERY THE CORPUS..." : "SELECT PAPERS TO BEGIN..."}
                disabled={selectedPapers.size === 0 || ask.isPending}
                className="flex-1 bg-black/50 border border-primary/30 rounded-sm px-4 py-3 font-sans text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:shadow-[0_0_15px_rgba(0,245,255,0.2)] transition-all disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!question.trim() || selectedPapers.size === 0 || ask.isPending}
                className="bg-primary text-primary-foreground px-6 rounded-sm flex items-center justify-center hover:bg-white transition-colors disabled:opacity-50"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </Shell>
  );
}
