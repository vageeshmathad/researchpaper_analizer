import React, { useState } from "react";
import { Shell } from "@/components/layout/Shell";
import { UploadCloud, FileText, CheckCircle2, AlertCircle, RefreshCw, Loader2 } from "lucide-react";
import { useIngestPapers, useListPapers, useDetectAllRelations } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import { Link } from "wouter";

export default function Upload() {
  const [isScanning, setIsScanning] = useState(false);
  const { toast } = useToast();
  const ingest = useIngestPapers();
  const detect = useDetectAllRelations();
  const { data: papers, isLoading: isLoadingPapers, refetch } = useListPapers();

  const handleIngest = async () => {
    setIsScanning(true);
    try {
      await ingest.mutateAsync({ data: { source: "csv" } });
      toast({ title: "INGESTION COMPLETE", description: "Base dataset seeded." });
      
      toast({ title: "DETECTING RELATIONS", description: "Initializing neural mapping..." });
      await detect.mutateAsync();
      toast({ title: "MAPPING COMPLETE", description: "Relations graph generated." });
      
      refetch();
    } catch (error) {
      toast({ variant: "destructive", title: "SYSTEM ERROR", description: "Failed to process data stream." });
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <Shell>
      <div className="container mx-auto px-6 py-12 max-w-7xl">
        <header className="mb-12">
          <h1 className="font-display text-4xl font-bold tracking-widest uppercase text-white mb-2">INGEST RESEARCH PAPERS</h1>
          <p className="font-sans text-muted-foreground text-sm tracking-wider uppercase">Initialize neural mapping across document corpus</p>
        </header>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div 
              className={`relative h-[400px] rounded-lg border-2 border-dashed flex flex-col items-center justify-center transition-all duration-500 overflow-hidden ${
                isScanning ? "border-primary bg-primary/5" : "border-primary/30 bg-card hover:border-primary hover:bg-card/50"
              }`}
            >
              {isScanning && (
                <div className="absolute inset-0 pointer-events-none">
                  <div className="w-full h-1 bg-primary/50 shadow-[0_0_15px_#00F5FF] animate-[scan_2s_ease-in-out_infinite]" />
                </div>
              )}

              <div className="z-10 flex flex-col items-center text-center p-6">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 transition-colors duration-500 ${isScanning ? "bg-primary/20 text-primary cyan-glow" : "bg-card border border-primary/20 text-primary/50"}`}>
                  {isScanning ? <RefreshCw className="w-10 h-10 animate-spin" /> : <UploadCloud className="w-10 h-10" />}
                </div>
                <h3 className="font-display text-xl font-bold text-white mb-2 tracking-wider">DROP PDF DATASTREAMS HERE</h3>
                <p className="font-sans text-sm text-muted-foreground mb-8">Supported formats: .pdf, .csv (seed data)</p>
                <button
                  onClick={handleIngest}
                  disabled={isScanning}
                  className="bg-primary/10 border border-primary text-primary px-8 py-3 rounded-sm font-sans font-bold tracking-widest text-sm hover:bg-primary hover:text-primary-foreground transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isScanning ? "PROCESSING..." : "INITIALIZE SEED DATA"}
                </button>
              </div>
            </div>

            {isScanning && (
              <div className="glass-panel p-6 rounded-sm space-y-4">
                <div className="flex justify-between font-sans text-xs tracking-widest text-muted-foreground uppercase">
                  <span>Neural Mapping Progress</span>
                  <span className="text-primary animate-pulse">Processing...</span>
                </div>
                <div className="h-2 w-full bg-card rounded-full overflow-hidden">
                  <div className="h-full bg-primary animate-pulse w-3/4 rounded-full shadow-[0_0_10px_#00F5FF]" />
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-1 space-y-6">
            <div className="flex items-center justify-between border-b border-card-border pb-4">
              <h2 className="font-display font-bold tracking-widest text-lg text-white">CORPUS</h2>
              <span className="font-sans text-xs text-primary tracking-widest bg-primary/10 px-2 py-1 rounded">
                {papers?.length || 0} FILES
              </span>
            </div>

            <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
              {isLoadingPapers ? (
                <div className="flex justify-center p-8"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
              ) : papers?.length === 0 ? (
                <div className="text-center p-8 border border-card-border border-dashed rounded-sm glass-panel">
                  <FileText className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
                  <p className="font-sans text-sm text-muted-foreground uppercase tracking-wider">No datastreams found</p>
                </div>
              ) : (
                papers?.map((paper, i) => (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    key={paper.id}
                    className="glass-panel p-4 rounded-sm hover-glow relative overflow-hidden group block"
                  >
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary/50 group-hover:bg-primary transition-colors" />
                    <Link href={`/paper/${paper.id}`} className="block pl-3 cursor-pointer">
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-sans text-[10px] text-primary bg-primary/10 px-2 py-0.5 rounded tracking-widest uppercase">
                          {paper.domain}
                        </span>
                        <span className="font-sans text-[10px] text-muted-foreground tracking-widest">
                          {paper.year}
                        </span>
                      </div>
                      <h3 className="font-sans font-bold text-sm text-white mb-1 line-clamp-2 leading-tight">
                        {paper.title}
                      </h3>
                      <p className="font-sans text-xs text-muted-foreground line-clamp-1 mb-3">
                        {paper.authors}
                      </p>
                      <div className="flex items-center gap-2 font-sans text-[10px] tracking-widest text-secondary">
                        <Network className="w-3 h-3" />
                        <span>{paper.relationCount || 0} RELATIONS</span>
                      </div>
                    </Link>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes scan {
          0% { transform: translateY(0); }
          50% { transform: translateY(400px); }
          100% { transform: translateY(0); }
        }
      `}} />
    </Shell>
  );
}
