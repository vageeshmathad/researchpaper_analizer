import React, { useState } from "react";
import { Shell } from "@/components/layout/Shell";
import { useGetStats, useListRelations, useGetReview, useGenerateReview, useListThemes } from "@workspace/api-client-react";
import { Network, Database, AlertTriangle, ShieldCheck, Search, SlidersHorizontal, ArrowRight, Loader2, RefreshCw } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

type FilterType = "all" | "agree" | "contradict" | "neutral" | "support";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetStats();
  const [filter, setFilter] = useState<FilterType>("all");
  const [search, setSearch] = useState("");
  const [confidence, setConfidence] = useState(0.5);
  
  const { data: relations, isLoading: relationsLoading } = useListRelations({
    type: filter === "all" ? undefined : filter,
    minConfidence: confidence,
  });
  
  const { data: review, isLoading: reviewLoading, refetch: refetchReview } = useGetReview();
  const generateReview = useGenerateReview();
  const { data: themes } = useListThemes();
  const { toast } = useToast();

  const handleGenerateReview = async () => {
    try {
      toast({ title: "SYNTHESIS INITIATED", description: "Compiling literature review..." });
      await generateReview.mutateAsync();
      toast({ title: "SYNTHESIS COMPLETE", description: "Review generated successfully." });
      refetchReview();
    } catch (e) {
      toast({ variant: "destructive", title: "ERROR", description: "Synthesis failed." });
    }
  };

  const statCards = [
    { label: "PAPERS", value: stats?.totalPapers || 0, icon: Database, color: "text-primary", border: "border-primary/30" },
    { label: "AGREEMENTS", value: stats?.agreements || 0, icon: ShieldCheck, color: "text-secondary", border: "border-secondary/30" },
    { label: "CONFLICTS", value: stats?.contradictions || 0, icon: AlertTriangle, color: "text-destructive", border: "border-destructive/30" },
    { label: "NEUTRAL", value: stats?.neutrals || 0, icon: Network, color: "text-accent", border: "border-accent/30" }
  ];

  return (
    <Shell>
      <div className="container mx-auto px-6 py-8 max-w-[1600px] h-[calc(100vh-3.5rem)] flex flex-col">
        <header className="mb-8 shrink-0">
          <h1 className="font-display text-3xl font-bold tracking-widest uppercase text-white mb-2">COMMAND CENTER</h1>
          <p className="font-sans text-muted-foreground text-xs tracking-wider uppercase">System intelligence overview</p>
        </header>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 shrink-0">
          {statCards.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                key={i} 
                className={`glass-panel p-6 rounded-sm border-l-2 ${stat.border} hover-glow relative overflow-hidden`}
              >
                <div className={`absolute top-0 right-0 p-4 opacity-10 ${stat.color}`}>
                  <Icon className="w-16 h-16" />
                </div>
                <div className="relative z-10">
                  <div className="font-sans text-xs tracking-widest text-muted-foreground mb-2 uppercase">{stat.label}</div>
                  <div className={`font-display text-4xl font-bold ${stat.color}`}>
                    {statsLoading ? <Loader2 className="w-8 h-8 animate-spin" /> : stat.value}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <div className="grid lg:grid-cols-3 gap-6 flex-1 min-h-0">
          <div className="lg:col-span-2 flex flex-col glass-panel rounded-sm overflow-hidden border border-card-border">
            <div className="p-4 border-b border-card-border bg-card/50 flex flex-wrap items-center justify-between gap-4 shrink-0">
              <div className="flex gap-2">
                {(["all", "agree", "contradict", "support", "neutral"] as FilterType[]).map(f => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`font-sans text-xs tracking-widest px-3 py-1.5 rounded-sm uppercase transition-all ${
                      filter === f 
                        ? f === 'contradict' ? 'bg-destructive/20 text-destructive border border-destructive/50' :
                          f === 'agree' ? 'bg-secondary/20 text-secondary border border-secondary/50' :
                          f === 'support' ? 'bg-primary/20 text-primary border border-primary/50' :
                          f === 'neutral' ? 'bg-accent/20 text-accent border border-accent/50' :
                          'bg-white/10 text-white border border-white/30'
                        : 'bg-transparent text-muted-foreground hover:bg-white/5 border border-transparent'
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 text-xs font-sans text-muted-foreground tracking-widest">
                  <SlidersHorizontal className="w-3 h-3" />
                  <span>CONF: {(confidence * 100).toFixed(0)}%</span>
                  <input 
                    type="range" 
                    min="0" max="1" step="0.1" 
                    value={confidence} 
                    onChange={e => setConfidence(parseFloat(e.target.value))}
                    className="w-24 accent-primary" 
                  />
                </div>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
              {relationsLoading ? (
                <div className="flex justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
              ) : relations?.length === 0 ? (
                <div className="text-center p-12 text-muted-foreground font-sans text-sm tracking-widest uppercase">No relations detected for criteria.</div>
              ) : (
                relations?.map((rel, i) => {
                  const isConflict = rel.relation === "contradict";
                  const isAgree = rel.relation === "agree";
                  const isSupport = rel.relation === "support";
                  
                  const colorClass = isConflict ? "border-destructive text-destructive" :
                                     isAgree ? "border-secondary text-secondary" :
                                     isSupport ? "border-primary text-primary" :
                                     "border-accent text-accent";
                                     
                  const bgClass = isConflict ? "bg-destructive/5" :
                                  isAgree ? "bg-secondary/5" :
                                  isSupport ? "bg-primary/5" :
                                  "bg-accent/5";

                  return (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: Math.min(i * 0.05, 0.5) }}
                      key={rel.id} 
                      className={`p-4 rounded-sm border-l-2 ${colorClass} ${bgClass} border-t border-r border-b border-transparent hover:border-card-border transition-colors group`}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <span className={`font-sans text-[10px] tracking-widest uppercase px-2 py-0.5 rounded-sm border ${colorClass} bg-black/20`}>
                          {rel.relation} ({(rel.confidence * 100).toFixed(1)}%)
                        </span>
                      </div>
                      <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-center mb-3">
                        <Link href={`/paper/${rel.paperIdA}`} className="font-sans text-sm text-white hover:text-primary transition-colors line-clamp-2">
                          {rel.paperTitleA || rel.paperIdA}
                        </Link>
                        <ArrowRight className={`w-4 h-4 ${colorClass}`} />
                        <Link href={`/paper/${rel.paperIdB}`} className="font-sans text-sm text-white hover:text-primary transition-colors line-clamp-2">
                          {rel.paperTitleB || rel.paperIdB}
                        </Link>
                      </div>
                      <p className="font-sans text-xs text-muted-foreground bg-black/20 p-2 rounded border border-white/5 line-clamp-2">
                        "{rel.evidenceText}"
                      </p>
                    </motion.div>
                  )
                })
              )}
            </div>
          </div>

          <div className="flex flex-col gap-6 flex-1 min-h-0">
            <div className="glass-panel flex-1 flex flex-col rounded-sm overflow-hidden border border-card-border">
              <div className="p-4 border-b border-card-border bg-card/50 flex justify-between items-center shrink-0">
                <h2 className="font-display font-bold tracking-widest text-sm text-white">LITERATURE REVIEW</h2>
                <button 
                  onClick={handleGenerateReview}
                  disabled={generateReview.isPending}
                  className="font-sans text-[10px] tracking-widest uppercase bg-primary/10 text-primary border border-primary/30 px-3 py-1 rounded-sm hover:bg-primary hover:text-primary-foreground transition-all disabled:opacity-50 flex items-center gap-2"
                >
                  {generateReview.isPending ? <RefreshCw className="w-3 h-3 animate-spin" /> : "SYNTHESIZE"}
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                {reviewLoading ? (
                   <div className="flex justify-center p-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
                ) : !review ? (
                  <div className="text-center p-12 text-muted-foreground font-sans text-xs tracking-widest uppercase">No review generated.</div>
                ) : (
                  <div className="space-y-6">
                    {review.sections.map((section, i) => (
                      <div key={i} className="space-y-2">
                        <h3 className="font-display text-primary text-sm font-bold tracking-widest uppercase border-b border-primary/20 pb-1">
                          {section.title}
                        </h3>
                        <p className="font-sans text-xs text-muted-foreground leading-relaxed">
                          {section.content}
                        </p>
                      </div>
                    ))}
                    {review.gaps?.length > 0 && (
                      <div className="space-y-2 mt-4 pt-4 border-t border-card-border">
                        <h3 className="font-display text-destructive text-sm font-bold tracking-widest uppercase border-b border-destructive/20 pb-1">
                          IDENTIFIED GAPS
                        </h3>
                        <ul className="list-disc pl-4 space-y-1">
                          {review.gaps.map((gap, i) => (
                            <li key={i} className="font-sans text-xs text-muted-foreground">{gap}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            <div className="glass-panel h-1/3 flex flex-col rounded-sm overflow-hidden border border-card-border shrink-0">
               <div className="p-4 border-b border-card-border bg-card/50 shrink-0">
                <h2 className="font-display font-bold tracking-widest text-sm text-white">THEMATIC CLUSTERS</h2>
              </div>
              <div className="flex-1 p-4 overflow-y-auto custom-scrollbar flex flex-wrap gap-2 content-start">
                {themes?.map((theme, i) => (
                  <div key={i} className="bg-white/5 border border-white/10 px-3 py-1.5 rounded-sm flex items-center gap-2">
                    <span className="font-sans text-xs text-white">{theme.name}</span>
                    <span className="bg-primary/20 text-primary text-[10px] px-1.5 rounded font-sans">{theme.paperCount}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}
