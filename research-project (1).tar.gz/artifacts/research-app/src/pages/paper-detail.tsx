import React from "react";
import { Shell } from "@/components/layout/Shell";
import { useGetPaper, useListRelations } from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { Loader2, ArrowLeft, Calendar, User, Network, FileText, ChevronRight, ArrowRight } from "lucide-react";

export default function PaperDetail() {
  const params = useParams();
  const id = params.id as string;

  const { data: paper, isLoading: paperLoading, error } = useGetPaper(id, {
    query: { enabled: !!id, queryKey: [`/api/papers/${id}`] }
  });

  const { data: relations, isLoading: relLoading } = useListRelations({ paperId: id }, {
    query: { enabled: !!id }
  });

  if (paperLoading) {
    return (
      <Shell>
        <div className="flex h-[calc(100vh-3.5rem)] items-center justify-center">
          <Loader2 className="w-12 h-12 text-primary animate-spin" />
        </div>
      </Shell>
    );
  }

  if (error || !paper) {
    return (
      <Shell>
        <div className="flex flex-col h-[calc(100vh-3.5rem)] items-center justify-center text-center px-6">
          <FileText className="w-16 h-16 text-destructive mb-4" />
          <h2 className="font-display text-2xl font-bold text-white mb-2">PAPER NOT FOUND</h2>
          <p className="font-sans text-muted-foreground mb-6">The requested document could not be located in the corpus.</p>
          <Link href="/dashboard" className="text-primary hover:text-white transition-colors font-sans tracking-widest text-sm flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" /> RETURN TO COMMAND
          </Link>
        </div>
      </Shell>
    );
  }

  return (
    <Shell>
      <div className="container mx-auto px-6 py-8 max-w-6xl">
        <Link href="/dashboard" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors font-sans text-xs tracking-widest uppercase mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to Dashboard
        </Link>

        {/* Hero Card */}
        <div className="glass-panel p-8 rounded-sm border-l-4 border-l-primary mb-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5 text-primary pointer-events-none">
            <FileText className="w-48 h-48" />
          </div>
          
          <div className="relative z-10">
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <span className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 rounded-sm font-sans text-xs tracking-widest uppercase">
                {paper.domain}
              </span>
              <span className="font-sans text-xs text-muted-foreground tracking-widest flex items-center gap-1">
                <Calendar className="w-3 h-3" /> {paper.year}
              </span>
              <span className="font-sans text-xs text-muted-foreground tracking-widest flex items-center gap-1">
                <Network className="w-3 h-3" /> {paper.relationCount || 0} RELATIONS
              </span>
            </div>
            
            <h1 className="font-sans font-bold text-2xl md:text-3xl text-white mb-4 leading-tight">
              {paper.title}
            </h1>
            
            <div className="flex items-center gap-2 text-muted-foreground font-sans text-sm mb-8">
              <User className="w-4 h-4" /> {paper.authors}
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-2 space-y-4">
                <h3 className="font-display text-xs text-white tracking-widest uppercase border-b border-card-border pb-2">ABSTRACT</h3>
                <p className="font-sans text-sm text-muted-foreground leading-relaxed">
                  {paper.abstract || "No abstract available in the datastream."}
                </p>
              </div>
              <div className="space-y-4">
                <h3 className="font-display text-xs text-white tracking-widest uppercase border-b border-card-border pb-2">KEY ENTITIES</h3>
                <div className="flex flex-wrap gap-2">
                  {paper.keywords?.map((kw, i) => (
                    <span key={i} className="bg-black/30 border border-white/10 px-2 py-1 rounded text-[10px] font-sans text-white tracking-wider">
                      {kw}
                    </span>
                  )) || <span className="text-xs text-muted-foreground">None extracted</span>}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Relations List */}
          <div className="glass-panel p-6 rounded-sm border border-card-border">
            <h2 className="font-display font-bold text-sm text-white tracking-widest uppercase mb-6 flex items-center gap-2">
              <Network className="w-4 h-4 text-primary" /> MAPPED RELATIONS
            </h2>
            
            <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
              {relLoading ? (
                 <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
              ) : relations?.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground font-sans text-xs tracking-widest uppercase">No external relations mapped.</div>
              ) : (
                relations?.map(rel => {
                  const isSourceA = rel.paperIdA === paper.id;
                  const otherId = isSourceA ? rel.paperIdB : rel.paperIdA;
                  const otherTitle = isSourceA ? rel.paperTitleB : rel.paperTitleA;
                  
                  const isConflict = rel.relation === "contradict";
                  const isAgree = rel.relation === "agree";
                  const isSupport = rel.relation === "support";
                  
                  const colorClass = isConflict ? "text-destructive border-destructive/30" :
                                     isAgree ? "text-secondary border-secondary/30" :
                                     isSupport ? "text-primary border-primary/30" :
                                     "text-accent border-accent/30";
                  
                  return (
                    <div key={rel.id} className="bg-black/30 border border-white/5 p-4 rounded-sm hover:border-white/20 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <span className={`font-sans text-[10px] tracking-widest uppercase px-2 py-0.5 rounded border ${colorClass}`}>
                          {rel.relation} ({(rel.confidence * 100).toFixed(0)}%)
                        </span>
                        <Link href={`/paper/${otherId}`} className="text-primary hover:text-white transition-colors">
                          <ChevronRight className="w-4 h-4" />
                        </Link>
                      </div>
                      <p className="font-sans text-xs text-white mb-2 line-clamp-2">{otherTitle || otherId}</p>
                      <p className="font-sans text-[11px] text-muted-foreground italic border-l-2 border-card-border pl-2 line-clamp-3">
                        "{rel.evidenceText}"
                      </p>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Quick Chat Context */}
          <div className="glass-panel p-6 rounded-sm border border-card-border flex flex-col">
            <h2 className="font-display font-bold text-sm text-white tracking-widest uppercase mb-6">CONTEXTUAL Q&A</h2>
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 bg-black/20 rounded border border-dashed border-card-border">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Terminal className="w-6 h-6 text-primary" />
              </div>
              <p className="font-sans text-sm text-muted-foreground mb-6">
                Query the AI specifically about this document's methodologies, findings, or gaps.
              </p>
              <Link href="/qa" className="bg-primary text-primary-foreground font-sans font-bold px-6 py-3 rounded-sm text-xs tracking-widest hover:bg-white transition-colors flex items-center gap-2">
                OPEN INTERROGATOR <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}
