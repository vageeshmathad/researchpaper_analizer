import React, { useEffect, useRef, useState } from "react";
import { Shell } from "@/components/layout/Shell";
import { useGetGraph } from "@workspace/api-client-react";
import { Loader2, Download, SlidersHorizontal, ZoomIn, ZoomOut, Maximize } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Graph() {
  const [minConf, setMinConf] = useState(0.5);
  const [relType, setRelType] = useState<string>("all");
  const [selectedNode, setSelectedNode] = useState<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { data: graphData, isLoading } = useGetGraph({
    minConfidence: minConf,
    relationType: relType === "all" ? undefined : relType
  });

  useEffect(() => {
    if (!graphData || !containerRef.current || !(window as any).d3) return;
    
    const d3 = (window as any).d3;
    const container = containerRef.current;
    container.innerHTML = "";
    
    const width = container.clientWidth;
    const height = container.clientHeight;

    const zoom = d3.zoom()
      .scaleExtent([0.1, 4])
      .on("zoom", (event: any) => {
        g.attr("transform", event.transform);
      });

    const svg = d3.select(container)
      .append("svg")
      .attr("width", width)
      .attr("height", height)
      .style("background", "transparent")
      .call(zoom);

    const g = svg.append("g");

    // Colors
    const colors = {
      agree: "#00FF88",
      contradict: "#FF3B5C",
      support: "#00F5FF",
      neutral: "#F5C518",
      domain: d3.scaleOrdinal(d3.schemeDark2)
    };

    // Simulation
    const simulation = d3.forceSimulation(graphData.nodes)
      .force("link", d3.forceLink(graphData.edges).id((d: any) => d.id).distance(150))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collision", d3.forceCollide().radius((d: any) => d.size * 2 + 10));

    // Glow filter
    const defs = svg.append("defs");
    const filter = defs.append("filter").attr("id", "glow");
    filter.append("feGaussianBlur").attr("stdDeviation", "2.5").attr("result", "coloredBlur");
    const feMerge = filter.append("feMerge");
    feMerge.append("feMergeNode").attr("in", "coloredBlur");
    feMerge.append("feMergeNode").attr("in", "SourceGraphic");

    // Links
    const link = g.append("g")
      .attr("class", "links")
      .selectAll("line")
      .data(graphData.edges)
      .enter().append("line")
      .attr("stroke-width", (d: any) => Math.max(1, d.confidence * 3))
      .attr("stroke", (d: any) => colors[d.relation as keyof typeof colors] || "#666")
      .attr("stroke-opacity", (d: any) => d.confidence)
      .style("filter", "url(#glow)");

    // Nodes
    const node = g.append("g")
      .attr("class", "nodes")
      .selectAll("circle")
      .data(graphData.nodes)
      .enter().append("circle")
      .attr("r", (d: any) => Math.max(5, Math.min(25, d.size * 3)))
      .attr("fill", (d: any) => colors.domain(d.domain))
      .attr("stroke", "#00F5FF")
      .attr("stroke-width", 1)
      .style("filter", "url(#glow)")
      .style("cursor", "pointer")
      .call(d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended))
      .on("click", (event: any, d: any) => {
        setSelectedNode(d);
        // Highlight connected
        node.style("opacity", (n: any) => isConnected(d, n) ? 1 : 0.1);
        link.style("opacity", (l: any) => l.source.id === d.id || l.target.id === d.id ? 1 : 0.05);
      });
      
    // Tooltips
    node.append("title")
      .text((d: any) => `${d.title} (${d.domain})`);

    // Labels (only for larger nodes)
    const labels = g.append("g")
      .attr("class", "labels")
      .selectAll("text")
      .data(graphData.nodes.filter((d: any) => d.size > 2))
      .enter().append("text")
      .text((d: any) => d.title.length > 20 ? d.title.substring(0, 20) + "..." : d.title)
      .attr("font-family", "Space Mono")
      .attr("font-size", "10px")
      .attr("fill", "#fff")
      .attr("dx", (d: any) => Math.max(5, Math.min(25, d.size * 3)) + 5)
      .attr("dy", 3)
      .style("pointer-events", "none");

    function isConnected(a: any, b: any) {
      return a.id === b.id || graphData.edges.some((e: any) => 
        (e.source.id === a.id && e.target.id === b.id) || 
        (e.source.id === b.id && e.target.id === a.id)
      );
    }

    simulation.on("tick", () => {
      link
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y);

      node
        .attr("cx", (d: any) => d.x)
        .attr("cy", (d: any) => d.y);
        
      labels
        .attr("x", (d: any) => d.x)
        .attr("y", (d: any) => d.y);
    });

    function dragstarted(event: any, d: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    }

    function dragged(event: any, d: any) {
      d.fx = event.x;
      d.fy = event.y;
    }

    function dragended(event: any, d: any) {
      if (!event.active) simulation.alphaTarget(0);
      d.fx = null;
      d.fy = null;
    }

    // Reset view on background click
    svg.on("click", (event: any) => {
      if (event.target.tagName === 'svg') {
        setSelectedNode(null);
        node.style("opacity", 1);
        link.style("opacity", (d: any) => d.confidence);
      }
    });

  }, [graphData]);

  return (
    <Shell>
      <div className="relative w-full h-[calc(100vh-3.5rem)] overflow-hidden bg-background">
        {/* Controls Overlay */}
        <div className="absolute top-6 left-6 z-10 glass-panel p-4 rounded-sm w-72 border border-primary/20 space-y-6">
          <div>
            <h3 className="font-display text-sm font-bold text-white tracking-widest mb-4">GRAPH PARAMS</h3>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="font-sans text-[10px] text-muted-foreground tracking-widest flex justify-between">
                  <span>MIN CONFIDENCE</span>
                  <span className="text-primary">{(minConf * 100).toFixed(0)}%</span>
                </label>
                <input 
                  type="range" 
                  min="0" max="1" step="0.05"
                  value={minConf}
                  onChange={(e) => setMinConf(parseFloat(e.target.value))}
                  className="w-full accent-primary"
                />
              </div>
              
              <div className="space-y-2">
                <label className="font-sans text-[10px] text-muted-foreground tracking-widest block">RELATION TYPE</label>
                <select 
                  value={relType}
                  onChange={(e) => setRelType(e.target.value)}
                  className="w-full bg-black/40 border border-card-border rounded-sm p-2 text-xs font-sans text-white focus:outline-none focus:border-primary/50"
                >
                  <option value="all">ALL TYPES</option>
                  <option value="agree">AGREEMENT</option>
                  <option value="contradict">CONTRADICTION</option>
                  <option value="support">SUPPORT</option>
                  <option value="neutral">NEUTRAL</option>
                </select>
              </div>
            </div>
          </div>
          
          <div className="pt-4 border-t border-card-border">
             <div className="grid grid-cols-2 gap-2 text-[10px] font-sans text-muted-foreground tracking-widest">
               <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-secondary"></span> AGREE</div>
               <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-destructive"></span> CONFLICT</div>
               <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-primary"></span> SUPPORT</div>
               <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-accent"></span> NEUTRAL</div>
             </div>
          </div>
        </div>

        {/* The Graph Canvas */}
        <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/50 backdrop-blur-sm z-20">
            <div className="text-center">
              <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto mb-4" />
              <div className="font-display tracking-widest text-primary text-sm animate-pulse">COMPUTING FORCE TOPOLOGY...</div>
            </div>
          </div>
        )}

        {/* Selected Node Panel */}
        <AnimatePresence>
          {selectedNode && (
            <motion.div 
              initial={{ opacity: 0, x: 300 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 300 }}
              className="absolute top-6 right-6 bottom-6 w-80 glass-panel border border-primary/30 p-6 flex flex-col z-10"
            >
              <div className="flex justify-between items-start mb-4">
                <span className="font-sans text-[10px] bg-primary/20 text-primary px-2 py-1 rounded-sm tracking-widest uppercase">
                  {selectedNode.domain}
                </span>
                <button onClick={() => setSelectedNode(null)} className="text-muted-foreground hover:text-white">✕</button>
              </div>
              <h2 className="font-sans font-bold text-lg text-white mb-2 leading-tight">{selectedNode.title}</h2>
              <div className="font-sans text-xs text-muted-foreground mb-6">YEAR: {selectedNode.year || "Unknown"}</div>
              
              <div className="flex-1 overflow-y-auto mt-4 pt-4 border-t border-card-border space-y-4 custom-scrollbar">
                <h3 className="font-display text-xs text-white tracking-widest">CONNECTIONS</h3>
                {graphData?.edges
                  .filter((e: any) => e.source.id === selectedNode.id || e.target.id === selectedNode.id)
                  .map((e: any, i: number) => {
                    const other = e.source.id === selectedNode.id ? e.target : e.source;
                    const isConflict = e.relation === "contradict";
                    const color = isConflict ? "text-destructive" : e.relation === "agree" ? "text-secondary" : e.relation === "support" ? "text-primary" : "text-accent";
                    
                    return (
                      <div key={i} className="bg-black/30 p-3 rounded-sm border border-white/5">
                        <div className={`font-sans text-[10px] ${color} tracking-widest uppercase mb-1`}>{e.relation}</div>
                        <div className="font-sans text-xs text-white line-clamp-2">{other.title}</div>
                      </div>
                    );
                  })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Shell>
  );
}
