import React from "react";
import { Shell } from "@/components/layout/Shell";
import { AlertTriangle, Home } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <Shell>
      <div className="flex flex-col h-[calc(100vh-3.5rem)] items-center justify-center text-center px-6 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-5">
          <div className="font-display text-[300px] font-black text-destructive select-none">404</div>
        </div>
        
        <div className="relative z-10 max-w-md">
          <div className="w-20 h-20 mx-auto rounded-full bg-destructive/10 flex items-center justify-center mb-8 border border-destructive/30 shadow-[0_0_30px_rgba(255,59,92,0.2)]">
            <AlertTriangle className="w-10 h-10 text-destructive" />
          </div>
          
          <h1 className="font-display text-3xl font-bold tracking-widest text-white mb-4 uppercase">
            SECTOR NOT FOUND
          </h1>
          
          <p className="font-sans text-muted-foreground mb-10 leading-relaxed text-sm">
            The requested coordinates map to empty space. The datastream you are looking for may have been archived or never existed in this timeline.
          </p>
          
          <Link 
            href="/"
            className="inline-flex items-center gap-2 bg-transparent border border-primary/50 text-primary hover:bg-primary hover:text-primary-foreground px-8 py-3 rounded-sm font-sans text-xs font-bold tracking-widest transition-all duration-300"
          >
            <Home className="w-4 h-4" /> RETURN TO ORIGIN
          </Link>
        </div>
      </div>
    </Shell>
  );
}
