import React, { useEffect, useRef } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { FileText, Network, Sparkles, BrainCircuit, Search } from "lucide-react";

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let nodes: any[] = [];
    let edges: any[] = [];

    const resize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      initGraph();
    };

    const initGraph = () => {
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      
      nodes = Array.from({ length: 12 }).map((_, i) => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        radius: Math.random() * 4 + 2,
        color: i % 3 === 0 ? "#00F5FF" : i % 3 === 1 ? "#00FF88" : "#FF3B5C",
      }));

      edges = [];
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          if (Math.random() > 0.7) {
            edges.push({ source: i, target: j });
          }
        }
      }
    };

    const draw = () => {
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      
      ctx.clearRect(0, 0, w, h);
      
      // Update physics
      nodes.forEach(node => {
        node.x += node.vx;
        node.y += node.vy;
        
        if (node.x < 0 || node.x > w) node.vx *= -1;
        if (node.y < 0 || node.y > h) node.vy *= -1;
      });

      // Draw edges
      edges.forEach(edge => {
        const s = nodes[edge.source];
        const t = nodes[edge.target];
        const dist = Math.hypot(t.x - s.x, t.y - s.y);
        
        if (dist < 150) {
          ctx.beginPath();
          ctx.moveTo(s.x, s.y);
          ctx.lineTo(t.x, t.y);
          ctx.strokeStyle = `rgba(255, 255, 255, ${1 - dist / 150})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      });

      // Draw nodes
      nodes.forEach(node => {
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
        ctx.fillStyle = node.color;
        ctx.fill();
        ctx.shadowColor = node.color;
        ctx.shadowBlur = 10;
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    window.addEventListener("resize", resize);
    resize();
    draw();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  const features = [
    { title: "Multi-PDF Ingestion", icon: FileText, desc: "Process thousands of pages instantly." },
    { title: "Conflict Detection", icon: Sparkles, desc: "Identify contradictions across domains." },
    { title: "Auto Literature Review", icon: BrainCircuit, desc: "Synthesize state-of-the-art reports." },
    { title: "Cross-Paper Q&A", icon: Search, desc: "Interrogate your entire knowledge base." },
    { title: "Citation Graph", icon: Network, desc: "Visualize dependencies visually." },
  ];

  return (
    <div className="min-h-[100dvh] bg-background text-foreground overflow-x-hidden selection:bg-primary/30">
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 -left-1/4 w-[1000px] h-[1000px] bg-primary/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 -right-1/4 w-[800px] h-[800px] bg-destructive/5 rounded-full blur-[120px]" />
      </div>

      <nav className="absolute top-0 w-full p-6 flex justify-between items-center z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary/10 border border-primary/30 flex items-center justify-center">
            <Search className="w-4 h-4 text-primary" />
          </div>
          <span className="font-display font-bold tracking-widest text-lg">ReSEARCH</span>
        </div>
        <div className="flex gap-6 text-sm font-sans tracking-wider text-muted-foreground">
          <span className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            SYSTEM ONLINE
          </span>
        </div>
      </nav>

      <main className="relative z-10 container mx-auto px-6 pt-32 pb-24 min-h-[100dvh] flex flex-col justify-center">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="flex flex-col gap-8"
          >
            <div className="space-y-4">
              <p className="font-sans text-primary tracking-[0.2em] text-sm font-bold uppercase">
                AI-12 · Research Synthesizer
              </p>
              <h1 className="font-display text-5xl md:text-7xl font-black leading-tight tracking-tight text-white drop-shadow-[0_0_15px_rgba(0,245,255,0.3)]">
                READ LESS.<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-white">
                  DISCOVER MORE.
                </span>
              </h1>
              <p className="font-sans text-lg text-muted-foreground max-w-xl leading-relaxed">
                Upload PDFs. The AI maps every agreement, contradiction, and knowledge gap across all papers. A command center for researchers in 2040.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <Link 
                href="/upload" 
                className="bg-primary text-primary-foreground font-sans font-bold px-8 py-4 rounded-sm tracking-widest hover:bg-white hover:text-background transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,245,255,0.5)] flex items-center gap-2"
              >
                START ANALYZING <Sparkles className="w-4 h-4" />
              </Link>
              <Link 
                href="/dashboard"
                className="glass-panel text-white font-sans font-bold px-8 py-4 rounded-sm tracking-widest hover-glow flex items-center gap-2"
              >
                VIEW DEMO
              </Link>
            </div>

            <div className="flex gap-8 pt-8 border-t border-card-border">
              <div>
                <div className="font-display text-3xl font-bold text-white">500+</div>
                <div className="font-sans text-xs text-muted-foreground tracking-widest uppercase mt-1">Papers mapped</div>
              </div>
              <div>
                <div className="font-display text-3xl font-bold text-primary">94.7%</div>
                <div className="font-sans text-xs text-muted-foreground tracking-widest uppercase mt-1">Accuracy</div>
              </div>
              <div>
                <div className="font-display text-3xl font-bold text-white">&lt; 2s</div>
                <div className="font-sans text-xs text-muted-foreground tracking-widest uppercase mt-1">Latency</div>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative h-[600px] w-full rounded-lg glass-panel overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-card to-transparent z-10 pointer-events-none" />
            <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-80" />
            <div className="absolute bottom-6 left-6 z-20 font-sans text-xs text-primary/70 tracking-widest">
              LIVE GRAPH PREVIEW // SIMULATING DATA
            </div>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-32 grid grid-cols-2 md:grid-cols-5 gap-4"
        >
          {features.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <div key={i} className="glass-panel p-6 rounded-sm hover-glow group">
                <Icon className="w-6 h-6 text-primary mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="font-sans font-bold text-sm tracking-wide text-white mb-2">{feature.title}</h3>
                <p className="text-xs text-muted-foreground font-sans">{feature.desc}</p>
              </div>
            );
          })}
        </motion.div>
      </main>
    </div>
  );
}
