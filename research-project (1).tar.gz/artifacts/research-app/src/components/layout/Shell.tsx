import React from "react";
import { Link, useLocation } from "wouter";
import { Database, Network, MessageSquare, LayoutDashboard, Search } from "lucide-react";

export function Shell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/dashboard", label: "COMMAND", icon: LayoutDashboard },
    { href: "/upload", label: "INGEST", icon: Database },
    { href: "/graph", label: "GRAPH", icon: Network },
    { href: "/qa", label: "INTERROGATE", icon: MessageSquare },
  ];

  return (
    <div className="min-h-[100dvh] w-full flex flex-col bg-background text-foreground overflow-hidden selection:bg-primary/30">
      <header className="h-14 border-b border-card-border flex items-center justify-between px-6 bg-card backdrop-blur-md z-50">
        <Link href="/" className="flex items-center gap-3 group">
          <div className="w-8 h-8 rounded bg-primary/10 border border-primary/30 flex items-center justify-center group-hover:cyan-glow transition-all">
            <Search className="w-4 h-4 text-primary" />
          </div>
          <span className="font-display font-bold tracking-widest text-lg">ReSEARCH</span>
        </Link>
        <nav className="flex items-center gap-1">
          {navItems.map((item) => {
            const isActive = location === item.href || location.startsWith(`${item.href}/`);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2 px-4 py-2 rounded-sm font-sans text-sm tracking-wider transition-all duration-300 ${
                  isActive
                    ? "bg-primary/10 text-primary border border-primary/30"
                    : "text-muted-foreground hover:text-primary hover:bg-white/5 border border-transparent"
                }`}
              >
                <Icon className="w-4 h-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </header>
      <main className="flex-1 relative overflow-y-auto">
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_top_right,rgba(0,245,255,0.05),transparent_50%)]" />
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_bottom_left,rgba(255,59,92,0.03),transparent_50%)]" />
        {children}
      </main>
    </div>
  );
}
