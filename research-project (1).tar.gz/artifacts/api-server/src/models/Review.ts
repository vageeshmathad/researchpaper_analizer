import { mongoose } from "../lib/mongodb";

const ReviewSectionSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
});

const ReviewSchema = new mongoose.Schema(
  {
    sections: { type: [ReviewSectionSchema], default: [] },
    gaps: { type: [String], default: [] },
    generatedAt: { type: Date, default: Date.now },
  },
  { timestamps: true },
);

export const Review =
  mongoose.models.Review || mongoose.model("Review", ReviewSchema);
