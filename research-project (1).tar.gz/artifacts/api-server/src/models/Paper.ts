import { mongoose } from "../lib/mongodb";

const PaperSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    authors: { type: String, required: true },
    domain: { type: String, required: true },
    year: { type: Number, required: true },
    abstract: { type: String, default: "" },
    keywords: { type: [String], default: [] },
    relationCount: { type: Number, default: 0 },
  },
  { timestamps: true },
);

export const Paper =
  mongoose.models.Paper || mongoose.model("Paper", PaperSchema);
