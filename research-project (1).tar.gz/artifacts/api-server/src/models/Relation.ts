import { mongoose } from "../lib/mongodb";

const RelationSchema = new mongoose.Schema(
  {
    paperIdA: { type: String, required: true },
    paperIdB: { type: String, required: true },
    paperTitleA: { type: String, default: "" },
    paperTitleB: { type: String, default: "" },
    relation: {
      type: String,
      enum: ["agree", "contradict", "support", "neutral"],
      required: true,
    },
    confidence: { type: Number, required: true, min: 0, max: 1 },
    evidenceText: { type: String, default: "" },
  },
  { timestamps: true },
);

export const Relation =
  mongoose.models.Relation || mongoose.model("Relation", RelationSchema);
