import { Router } from "express";
import { Relation } from "../models/Relation";
import { Paper } from "../models/Paper";
import { ListRelationsQueryParams } from "@workspace/api-zod";

const router = Router();

const RELATION_TYPES = ["agree", "contradict", "support", "neutral"] as const;
const EVIDENCE_TEMPLATES = [
  "Both papers demonstrate consistent findings regarding {topic}, with {metric} showing similar trends.",
  "The experimental results in paper B directly contradict the conclusions of paper A regarding {topic}.",
  "Paper B extends and supports the foundational work in paper A by providing additional empirical evidence on {topic}.",
  "The methodological approaches diverge on {topic}, leading to neutral comparison without clear precedence.",
];

function getRandomElement<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

router.get("/relations", async (req, res) => {
  try {
    const query = ListRelationsQueryParams.parse(req.query);
    const filter: Record<string, any> = {};

    if (query.type) filter.relation = query.type;
    if (query.minConfidence !== undefined)
      filter.confidence = { $gte: query.minConfidence };
    if (query.paperId)
      filter.$or = [{ paperIdA: query.paperId }, { paperIdB: query.paperId }];

    const relations = await Relation.find(filter).lean() as any[];
    res.json(
      relations.map((r) => ({
        id: r._id.toString(),
        paperIdA: r.paperIdA,
        paperIdB: r.paperIdB,
        paperTitleA: r.paperTitleA,
        paperTitleB: r.paperTitleB,
        relation: r.relation,
        confidence: r.confidence,
        evidenceText: r.evidenceText,
      })),
    );
  } catch (err) {
    req.log.error({ err }, "Failed to list relations");
    res.status(500).json({ message: "Failed to list relations" });
  }
});

router.post("/relations/detect", async (req, res) => {
  try {
    const papers = await Paper.find().lean() as any[];
    if (papers.length < 2) {
      res.json({
        relationsCreated: 0,
        message: "Not enough papers to detect relations",
      });
      return;
    }

    await Relation.deleteMany({});

    const relations: any[] = [];
    const topics = [
      "model accuracy",
      "training efficiency",
      "generalization",
      "scalability",
      "robustness",
    ];

    for (let i = 0; i < papers.length; i++) {
      for (let j = i + 1; j < papers.length; j++) {
        if (Math.random() > 0.45) continue;
        const pA = papers[i];
        const pB = papers[j];
        const relationType = getRandomElement([...RELATION_TYPES]);
        const confidence = parseFloat((0.5 + Math.random() * 0.5).toFixed(2));
        const topic = getRandomElement(topics);
        const evidenceTemplate = getRandomElement(EVIDENCE_TEMPLATES);
        const evidenceText = evidenceTemplate.replace(/{topic}/g, topic).replace(/{metric}/g, "accuracy scores");

        relations.push({
          paperIdA: pA._id.toString(),
          paperIdB: pB._id.toString(),
          paperTitleA: pA.title,
          paperTitleB: pB.title,
          relation: relationType,
          confidence,
          evidenceText,
        });
      }
    }

    const created = await Relation.insertMany(relations);

    for (const paper of papers) {
      const count = await Relation.countDocuments({
        $or: [
          { paperIdA: paper._id.toString() },
          { paperIdB: paper._id.toString() },
        ],
      });
      await Paper.findByIdAndUpdate(paper._id, { relationCount: count });
    }

    res.json({
      relationsCreated: created.length,
      message: `Detected and stored ${created.length} relations`,
    });
  } catch (err) {
    req.log.error({ err }, "Relation detection failed");
    res.status(500).json({ message: "Relation detection failed" });
  }
});

export default router;
