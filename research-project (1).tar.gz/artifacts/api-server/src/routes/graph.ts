import { Router } from "express";
import { Paper } from "../models/Paper";
import { Relation } from "../models/Relation";
import { GetGraphQueryParams } from "@workspace/api-zod";

const router = Router();

router.get("/graph", async (req, res) => {
  try {
    const query = GetGraphQueryParams.parse(req.query);
    const relFilter: Record<string, any> = {};

    if (query.minConfidence !== undefined)
      relFilter.confidence = { $gte: query.minConfidence };
    if (query.relationType) relFilter.relation = query.relationType;

    const papers = await Paper.find().lean() as any[];
    const relations = await Relation.find(relFilter).lean() as any[];

    const papersInRelations = new Set<string>();
    relations.forEach((r) => {
      papersInRelations.add(r.paperIdA);
      papersInRelations.add(r.paperIdB);
    });

    const nodes = papers
      .filter(
        (p) =>
          papersInRelations.has(p._id.toString()) || relations.length === 0,
      )
      .map((p) => ({
        id: p._id.toString(),
        title: p.title,
        domain: p.domain,
        year: p.year,
        size: p.relationCount || 1,
      }));

    const edges = relations.map((r) => ({
      source: r.paperIdA,
      target: r.paperIdB,
      relation: r.relation,
      confidence: r.confidence,
    }));

    res.json({ nodes, edges });
  } catch (err) {
    req.log.error({ err }, "Failed to get graph");
    res.status(500).json({ message: "Failed to get graph data" });
  }
});

export default router;
