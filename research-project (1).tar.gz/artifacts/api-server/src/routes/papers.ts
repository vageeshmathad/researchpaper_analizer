import { Router } from "express";
import { Paper } from "../models/Paper";
import { Relation } from "../models/Relation";
import {
  IngestPapersBody,
  GetPaperParams,
} from "@workspace/api-zod";

const router = Router();

const SEED_PAPERS = [
  {
    title: "Attention Is All You Need",
    authors: "Vaswani et al.",
    domain: "NLP",
    year: 2017,
    abstract:
      "The dominant sequence transduction models are based on complex recurrent or convolutional neural networks. We propose a new simple network architecture, the Transformer, based solely on attention mechanisms.",
    keywords: ["transformer", "attention", "neural network", "NLP"],
  },
  {
    title: "BERT: Pre-training of Deep Bidirectional Transformers",
    authors: "Devlin et al.",
    domain: "NLP",
    year: 2018,
    abstract:
      "We introduce BERT, which stands for Bidirectional Encoder Representations from Transformers. Unlike recent language representation models, BERT is designed to pre-train deep bidirectional representations.",
    keywords: ["BERT", "pre-training", "language model", "NLP"],
  },
  {
    title: "GPT-4 Technical Report",
    authors: "OpenAI",
    domain: "AI",
    year: 2023,
    abstract:
      "We report the development of GPT-4, a large multimodal model capable of processing image and text inputs. GPT-4 exhibits human-level performance on various professional and academic benchmarks.",
    keywords: ["GPT-4", "large language model", "multimodal", "AI"],
  },
  {
    title: "Deep Residual Learning for Image Recognition",
    authors: "He et al.",
    domain: "Computer Vision",
    year: 2015,
    abstract:
      "We present a residual learning framework to ease training of deep neural networks. We provide comprehensive empirical evidence showing that residual networks are easier to optimize.",
    keywords: ["ResNet", "residual learning", "image recognition", "deep learning"],
  },
  {
    title: "Generative Adversarial Networks",
    authors: "Goodfellow et al.",
    domain: "Generative AI",
    year: 2014,
    abstract:
      "We propose a new framework for estimating generative models via an adversarial process, in which we simultaneously train two models: a generative model G and a discriminative model D.",
    keywords: ["GAN", "generative model", "adversarial training"],
  },
  {
    title: "Dropout: A Simple Way to Prevent Neural Networks from Overfitting",
    authors: "Srivastava et al.",
    domain: "Machine Learning",
    year: 2014,
    abstract:
      "We describe the dropout technique, which addresses the problem of overfitting in neural networks. Key idea is to randomly drop units during training to prevent co-adaptation of feature detectors.",
    keywords: ["dropout", "regularization", "overfitting", "neural network"],
  },
  {
    title: "ImageNet Large Scale Visual Recognition Challenge",
    authors: "Russakovsky et al.",
    domain: "Computer Vision",
    year: 2015,
    abstract:
      "The ImageNet Large Scale Visual Recognition Challenge (ILSVRC) is a benchmark in object category classification and detection on hundreds of object categories and millions of images.",
    keywords: ["ImageNet", "object detection", "classification", "benchmark"],
  },
  {
    title: "Playing Atari with Deep Reinforcement Learning",
    authors: "Mnih et al.",
    domain: "Reinforcement Learning",
    year: 2013,
    abstract:
      "We present the first deep learning model to successfully learn control policies directly from high-dimensional sensory input using reinforcement learning.",
    keywords: ["DQN", "reinforcement learning", "deep learning", "Atari"],
  },
  {
    title: "The Lottery Ticket Hypothesis",
    authors: "Frankle and Carlin",
    domain: "Machine Learning",
    year: 2019,
    abstract:
      "We identify a training phenomenon: a randomly-initialized, dense neural network contains a subnetwork that is initialized such that—when trained in isolation—it can match the test accuracy of the original network.",
    keywords: ["sparse networks", "pruning", "lottery ticket", "neural network"],
  },
  {
    title: "Scaling Laws for Neural Language Models",
    authors: "Kaplan et al.",
    domain: "NLP",
    year: 2020,
    abstract:
      "We study empirical scaling laws for language model performance on the cross-entropy loss. The loss scales as a power-law with model size, dataset size, and the amount of compute used for training.",
    keywords: ["scaling laws", "language model", "compute", "NLP"],
  },
];

router.get("/papers", async (req, res) => {
  try {
    const papers = await Paper.find().lean();
    res.json(
      papers.map((p: any) => ({
        id: p._id.toString(),
        title: p.title,
        authors: p.authors,
        domain: p.domain,
        year: p.year,
        abstract: p.abstract,
        keywords: p.keywords,
        relationCount: p.relationCount || 0,
      })),
    );
  } catch (err) {
    req.log.error({ err }, "Failed to list papers");
    res.status(500).json({ message: "Failed to fetch papers" });
  }
});

router.get("/papers/stats", async (req, res) => {
  try {
    const totalPapers = await Paper.countDocuments();
    const agreements = await Relation.countDocuments({ relation: "agree" });
    const contradictions = await Relation.countDocuments({
      relation: "contradict",
    });
    const neutrals = await Relation.countDocuments({ relation: "neutral" });
    res.json({ totalPapers, agreements, contradictions, neutrals });
  } catch (err) {
    req.log.error({ err }, "Failed to get stats");
    res.status(500).json({ message: "Failed to get stats" });
  }
});

router.post("/papers/ingest", async (req, res) => {
  try {
    const body = IngestPapersBody.parse(req.body);
    if (body.source === "csv") {
      const existing = await Paper.countDocuments();
      if (existing > 0) {
        res.json({ count: existing, message: "Corpus already populated" });
        return;
      }
      const created = await Paper.insertMany(SEED_PAPERS);
      res.json({
        count: created.length,
        message: `Ingested ${created.length} papers successfully`,
      });
    } else {
      res.status(400).json({ message: "Unsupported source" });
    }
  } catch (err) {
    req.log.error({ err }, "Ingestion failed");
    res.status(500).json({ message: "Ingestion failed" });
  }
});

router.get("/papers/:id", async (req, res) => {
  try {
    const params = GetPaperParams.parse(req.params);
    const paper = await Paper.findById(params.id).lean() as any;
    if (!paper) {
      res.status(404).json({ message: "Paper not found" });
      return;
    }
    const rCount = await Relation.countDocuments({
      $or: [
        { paperIdA: paper._id.toString() },
        { paperIdB: paper._id.toString() },
      ],
    });
    res.json({
      id: paper._id.toString(),
      title: paper.title,
      authors: paper.authors,
      domain: paper.domain,
      year: paper.year,
      abstract: paper.abstract,
      keywords: paper.keywords,
      relationCount: rCount,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get paper");
    res.status(500).json({ message: "Failed to get paper" });
  }
});

export default router;
