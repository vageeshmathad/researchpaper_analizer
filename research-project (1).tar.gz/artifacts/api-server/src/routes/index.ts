import { Router, type IRouter } from "express";
import healthRouter from "./health";
import papersRouter from "./papers";
import relationsRouter from "./relations";
import graphRouter from "./graph";
import reviewRouter from "./review";
import themesRouter from "./themes";
import qaRouter from "./qa";

const router: IRouter = Router();

router.use(healthRouter);
router.use(papersRouter);
router.use(relationsRouter);
router.use(graphRouter);
router.use(reviewRouter);
router.use(themesRouter);
router.use(qaRouter);

export default router;
