import { Router } from "express";
import { Paper } from "../models/Paper";

const router = Router();

router.get("/themes", async (req, res) => {
  try {
    const papers = await Paper.find().lean() as any[];

    const keywordCounts: Record<string, number> = {};
    for (const paper of papers) {
      for (const kw of (paper.keywords || [])) {
        const key = (kw as string).toLowerCase().trim();
        keywordCounts[key] = (keywordCounts[key] || 0) + 1;
      }
    }

    const domainCounts: Record<string, number> = {};
    for (const paper of papers) {
      const d = paper.domain as string;
      domainCounts[d] = (domainCounts[d] || 0) + 1;
    }

    const themes: Array<{ name: string; paperCount: number }> = [];

    for (const [name, count] of Object.entries(domainCounts)) {
      themes.push({ name: name.toUpperCase(), paperCount: count as number });
    }

    for (const [name, count] of Object.entries(keywordCounts)) {
      if ((count as number) >= 2) {
        themes.push({ name: name, paperCount: count as number });
      }
    }

    themes.sort((a, b) => b.paperCount - a.paperCount);

    res.json(themes.slice(0, 20));
  } catch (err) {
    req.log.error({ err }, "Failed to list themes");
    res.status(500).json({ message: "Failed to list themes" });
  }
});

export default router;
